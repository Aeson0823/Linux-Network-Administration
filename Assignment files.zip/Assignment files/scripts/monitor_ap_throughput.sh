#!/bin/bash
IFACE="wlxb8fbb3d99e51"
INTERVAL=1

RX_PREV=$(cat /sys/class/net/$IFACE/statistics/rx_bytes)
TX_PREV=$(cat /sys/class/net/$IFACE/statistics/tx_bytes)

echo "Monitoring throughput on $IFACE"
while true; do
	sleep "$INTERVAL"
	RX_NOW=$(cat /sys/class/net/$IFACE/statistics/rx_bytes)
	TX_NOW=$(cat /sys/class/net/$IFACE/statistics/tx_bytes)
	RX_RATE=$((	(RX_NOW - RX_PREV) / 1024 / INTERVAL ))
	TX_RATE=$((	(TX_NOW - TX_PREV) / 1024 / INTERVAL ))
	echo "$(date '+%H:%M:%S') IN: ${RX_RATE} KB/s OUT: ${TX_RATE} KB/s"
	RX_PREV=$RX_NOW
	TX_PREV=$TX_NOW
done
