#!/bin/bash
# Text formatting colors
Green='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'

NC='\033[0m' # No Color
echo -e "${CYAN}========================================================${NC}"
echo -e "${YELLOW}	WEB SERVER PERFORMANCE MONITORING SCRIPT	${NC}"
echo -e "${CYAN}========================================================${NC}"

CONNECTED_CLIENTS=$(netstat -an | grep "Cpu(s)" | sed "s/.*, *\([0-9.]*\)%* id.*/\1/" | awk '{print 100 - $1}')
echo -e "${GREEN}[+] Current CPU Utilization:${NC} $CPU_USAGE%"

R1=$(cat /sys/class/net/br0/statistics/rx_bytes)
T1=$(cat /sys/class/net/br0/statistics/rx_bytes)
sleep 1
R2=$(cat /sys/class/net/br0/statistics/rx_bytes)
T2=$(cat /sys/class/net/br0/statistics/rx_bytes)

RXKB=$(echo "scale=2; ($R2 - $R1) / 1024" | bc)
TXKB=$(echo "scale=2; ($T2 - $T1) / 1024" | bc)

echo -e "${GREEN}[+] Bandwidth Utilization (br0):${NC}"
echo -e "	- Download Speed: $RXKB KB/s"
echo -e "       - Upload Speed:	 $TXKB KB/s"
echo -e "${CYAN}========================================================${NC}" 

